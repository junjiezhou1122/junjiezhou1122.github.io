const path = require('path');
const fs = require('fs');

const configPath = path.join(__dirname, '..', 'config.json');
let ddgTokenUsed = false;
let ddgTokenReserved = false;

function normalizeConfig(rawConfig = {}) {
    const mode = rawConfig.mode;
    const ddg = rawConfig.ddg;
    const mail = rawConfig.mail;
    const clearMailbox = rawConfig.clearMailbox;

    return {
        mode,
        ddg,
        mailConfig: mail,
        mail: mail?.mail,
        ddgToken: ddg?.ddgToken,
        mailInboxUrl: mode === 'ddg' ? ddg?.mailInboxUrl : mail?.mailInboxUrl,
        clearMailbox,
        oauthClientId: rawConfig.oauthClientId,
        oauthRedirectPort: rawConfig.oauthRedirectPort
    };
}

function loadConfig() {
    if (!fs.existsSync(configPath)) {
        console.error('[Config] 没有找到 config.json');
        return {};
    }

    try {
        const content = fs.readFileSync(configPath, 'utf8');
        return normalizeConfig(JSON.parse(content));
    } catch (error) {
        console.error('[Config] 解析 config.json 失败:', error.message);
        return {};
    }
}

const currentConfig = loadConfig();

function markDdgTokenUsed(token) {
    if (token) {
        ddgTokenReserved = false;
        ddgTokenUsed = true;
    }
}

function isDdgTokenUsed(token) {
    return Boolean(token) && ddgTokenUsed;
}

function reserveDdgToken(token) {
    if (token) {
        ddgTokenReserved = true;
    }
}

function releaseDdgToken(token) {
    if (token) {
        ddgTokenReserved = false;
    }
}

function isDdgTokenReserved(token) {
    return Boolean(token) && ddgTokenReserved;
}

function hasAvailableConfig() {
    if (!currentConfig || Object.keys(currentConfig).length === 0) {
        return null;
    }

    if (currentConfig.mode !== 'ddg') {
        return true;
    }

    return Boolean(currentConfig.ddgToken) && !isDdgTokenUsed(currentConfig.ddgToken) && !isDdgTokenReserved(currentConfig.ddgToken);
}

module.exports = {
    hasAvailableConfig,
    markDdgTokenUsed,
    isDdgTokenUsed,
    reserveDdgToken,
    releaseDdgToken,
    isDdgTokenReserved,
    currentConfig,

    get mode() {
        return currentConfig.mode;
    },

    get mail() {
        return currentConfig.mail;
    },

    get mailInboxUrl() {
        return currentConfig.mailInboxUrl;
    },

    get ddgToken() {
        return currentConfig.ddgToken;
    },

    get clearMailbox() {
        return currentConfig.clearMailbox;
    },

    get oauthClientId() {
        return currentConfig.oauthClientId;
    },

    get oauthRedirectPort() {
        return currentConfig.oauthRedirectPort;
    }
};
