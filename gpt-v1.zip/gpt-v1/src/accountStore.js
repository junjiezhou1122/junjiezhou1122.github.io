const fs = require('fs');
const path = require('path');

class AccountStore {
    constructor() {
        this.filePath = path.join(process.cwd(), 'accounts.json');
        this.writeQueue = Promise.resolve();
    }

    async ensureStoreFile() {
        const dirPath = path.dirname(this.filePath);
        await fs.promises.mkdir(dirPath, { recursive: true });

        if (!fs.existsSync(this.filePath)) {
            await fs.promises.writeFile(this.filePath, '{}', 'utf8');
        }
    }

    async readStore() {
        await this.ensureStoreFile();
        await this.writeQueue;

        const content = await fs.promises.readFile(this.filePath, 'utf8');
        if (!content.trim()) {
            return {};
        }

        return JSON.parse(content);
    }

    async queueWrite(mutator) {
        const runWrite = async () => {
            await this.ensureStoreFile();

            const content = await fs.promises.readFile(this.filePath, 'utf8');
            const store = content.trim() ? JSON.parse(content) : {};
            const nextStore = await mutator(store);

            await fs.promises.writeFile(this.filePath, `${JSON.stringify(nextStore, null, 2)}\n`, 'utf8');
            return nextStore;
        };

        const nextTask = this.writeQueue.then(runWrite, runWrite);
        this.writeQueue = nextTask.then(() => undefined, () => undefined);
        return nextTask;
    }

    async hasAccount(email) {
        const store = await this.readStore();
        return Object.prototype.hasOwnProperty.call(store, email);
    }

    async createAccount(email, password, status = 'generated') {
        await this.queueWrite((store) => {
            if (!store[email]) {
                store[email] = {
                    password,
                    status,
                    refresh_token: null
                };
            }

            return store;
        });
    }

    async updateStatus(email, status) {
        await this.queueWrite((store) => {
            if (!store[email]) {
                throw new Error(`账户 ${email} 不存在，无法更新状态`);
            }

            store[email].status = status;
            return store;
        });
    }

    async updateRefreshToken(email, refreshToken) {
        await this.queueWrite((store) => {
            if (!store[email]) {
                throw new Error(`账户 ${email} 不存在，无法更新 refresh_token`);
            }

            store[email].refresh_token = refreshToken || null;
            return store;
        });
    }
}

module.exports = { AccountStore };
