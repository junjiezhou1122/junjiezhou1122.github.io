const crypto = require('crypto');
const { DDGEmailProvider } = require('./ddg');

function formatMailUser(fullName) {
    return fullName
        .trim()
        .toLowerCase()
        .replace(/[^a-z\s-]/g, '')
        .replace(/\s+/g, '')
        .replace(/-+/g, '');
}

class TemplateMailProvider {
    constructor(currentConfig) {
        this.currentConfig = currentConfig;
        this.emailAddress = null;
        this.mailInboxUrl = null;
    }

    buildMailAddress(userData) {
        const template = this.currentConfig.mailConfig?.mail || this.currentConfig.mail;
        if (!template) {
            throw new Error('未配置 mail，请检查配置文件');
        }

        const mailUser = `${formatMailUser(userData.fullName)}${crypto.randomBytes(3).toString('hex')}`;
        return template.replaceAll('{user}', mailUser);
    }

    buildMailInboxUrl(mail) {
        const mailInboxUrl = this.currentConfig.mailConfig?.mailInboxUrl || this.currentConfig.mailInboxUrl;
        if (!mailInboxUrl) {
            throw new Error('未配置 mailInboxUrl，请检查配置文件');
        }

        return mailInboxUrl.replaceAll('{mail}', mail);
    }

    async prepare(userData) {
        this.emailAddress = this.buildMailAddress(userData);
        this.mailInboxUrl = this.buildMailInboxUrl(this.emailAddress);
        return this.emailAddress;
    }

    getEmail() {
        return this.emailAddress;
    }

    getMailInboxUrl() {
        return this.mailInboxUrl;
    }
}

class DdgMailProvider {
    constructor(currentConfig) {
        this.currentConfig = currentConfig;
        this.ddgProvider = new DDGEmailProvider(currentConfig);
    }

    async prepare() {
        await this.ddgProvider.generateAlias();
        return this.ddgProvider.getEmail();
    }

    getEmail() {
        return this.ddgProvider.getEmail();
    }

    getMailInboxUrl() {
        const mailInboxUrl = this.currentConfig.ddg?.mailInboxUrl || this.currentConfig.mailInboxUrl;
        if (!mailInboxUrl) {
            throw new Error('未配置 DDG mailInboxUrl，请检查配置文件');
        }

        return mailInboxUrl;
    }
}

function createEmailProvider(currentConfig) {
    const mode = currentConfig?.mode || 'mail';

    if (mode === 'ddg') {
        return new DdgMailProvider(currentConfig);
    }

    return new TemplateMailProvider(currentConfig);
}

module.exports = {
    createEmailProvider,
    formatMailUser
};
