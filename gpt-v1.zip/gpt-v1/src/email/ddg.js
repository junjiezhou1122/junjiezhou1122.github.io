const axios = require('axios');
const config = require('../config');

class DDGEmailProvider {
    constructor(currentConfig) {
        this.currentConfig = currentConfig;
        this.token = this.currentConfig.ddgToken;
        this.emailAddress = null;
        this.previousEmailAddress = null; // 用于检测连续两次相同的邮箱别名
    }

    /**
     * 生成 DDG 邮箱别名
     * @returns {Promise<string>} 邮箱地址 (xxx@duck.com)
     */
    async generateAlias() {
        try {
            const response = await axios.post(
                'https://quack.duckduckgo.com/api/email/addresses',
                {},
                {
                    headers: {
                        'Authorization': `Bearer ${this.token}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            // 响应格式: {"address":"a-b-c"}
            const address = response.data.address;
            this.previousEmailAddress = this.emailAddress; // 保存之前的邮箱地址
            this.emailAddress = `${address}@duck.com`;

            console.log(`[DDG] 生成邮箱别名: ${this.emailAddress}`);

            // 检查是否连续两次生成相同的邮箱别名
            if (this.previousEmailAddress && this.previousEmailAddress === this.emailAddress) {
                console.log(`[DDG] 检测到连续两次相同的邮箱别名: ${this.emailAddress}，标记当前DDG token为已使用`);
                config.markDdgTokenUsed(this.token);
            }

            return this.emailAddress;
        } catch (error) {
            console.error('[DDG] 生成邮箱别名失败:', error.message);
            if (error.response) {
                console.error('[DDG] 响应状态:', error.response.status);
                console.error('[DDG] 响应数据:', error.response.data);
            }
            throw error;
        }
    }

    /**
     * 获取当前邮箱地址
     * @returns {string|null}
     */
    getEmail() {
        return this.emailAddress;
    }
}

module.exports = { DDGEmailProvider };
