const path = require('path');
const fs = require('fs');
const { AccountStore } = require('./src/accountStore');
const { BrowserbaseService } = require('./src/browserbaseService');
const { OAuthService } = require('./src/oauthService');
const { generateRandomName, generateRandomPassword } = require('./src/randomIdentity');
const config = require('./src/config');
const { createEmailProvider } = require('./src/email/mail');

// 目标生成数量和并发数
const TARGET_COUNT = parseInt(process.argv[2], 10) || 1;
const CONCURRENT_LIMIT = parseInt(process.argv[3], 10) || 1; // 默认为1，即串行

/**
 * 生成随机用户数据
 */
function generateUserData() {
    const fullName = generateRandomName();
    const password = generateRandomPassword();

    // 生成出生日期 (25-40岁)
    const age = 25 + Math.floor(Math.random() * 16);
    const birthYear = new Date().getFullYear() - age;
    const birthMonth = 1 + Math.floor(Math.random() * 12);
    const birthDay = 1 + Math.floor(Math.random() * 28);
    const birthDate = `${birthYear}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`;

    return {
        fullName,
        password,
        age,
        birthDate,
        birthMonth,
        birthDay,
        birthYear,
        mail: null,
        mailInboxUrl: null,
        lastUrl: null
    };
}

function formatStatusText(statusLabel, lastUrl) {
    return `${statusLabel} ${lastUrl || ''}`;
}

async function generateUniqueUserData(currentConfig, accountStore) {
    for (let attempt = 1; attempt <= 100; attempt += 1) {
        const userData = generateUserData();
        const emailProvider = createEmailProvider(currentConfig);
        await emailProvider.prepare(userData);
        userData.mail = emailProvider.getEmail();
        userData.mailInboxUrl = emailProvider.getMailInboxUrl();

        if (await accountStore.hasAccount(userData.mail)) {
            console.log(`[主程序] 检测到重复邮箱，重新生成 (${attempt}/100): ${userData.mail}`);
            continue;
        }

        return userData;
    }

    throw new Error('连续 100 次生成邮箱均重复，无法创建新账户');
}

/**
 * 第一阶段：ChatGPT 注册
 */
async function phase1(browserbase, userData) {
    console.log('\n=========================================');
    console.log('[阶段1] 开始 ChatGPT 注册流程');
    console.log('=========================================');

    // 创建会话
    const session = await browserbase.createSession();

    // 构建 Agent Goal
    const goal = `请打开chatgpt的对话页面，点击创建一个账户，使用${userData.mail}作为邮箱，${userData.password}作为密码，发送验证码后在${userData.mailInboxUrl}上等待接收自己的邮箱验证码${config.clearMailbox.enable ? config.clearMailbox.prompt : ''}，接下来使用${userData.fullName}作为全名，${userData.birthDate}作为出生日期（注意如果框里面要填年龄的话换算为年龄），创建账户后导航到\`data:text/html,<html><head><title>MISSION_ACCOMPLISHED</title></head><body>MISSION_ACCOMPLISHED</body></html>\`，等待3秒并结束。

完成任务之前不能结束, 每次等待的时间不得超过3秒。`;

    console.log('[阶段1] Agent Goal 已准备');

    // 发送 Agent 任务（不等待 EventStream）
    browserbase.sendAgentGoal(goal).catch(e => {
        console.error(`[阶段1] Agent 任务流异常: ${e.message}`);
    });

    // 连接 CDP 监控 URL 变化
    const wsUrl = session.wsUrl;
    if (!wsUrl) {
        throw new Error('无法从 sessionUrl 中提取 WSS 地址');
    }

    console.log('[阶段1] 开始监控页面 URL 变化，等待到达 MISSION_ACCOMPLISHED 页面...');

    // 监控直到到达 MISSION_ACCOMPLISHED 页面
    let finalUrl;
    try {
        finalUrl = await browserbase.connectToCDP(wsUrl, {
            targetKeyword: 'MISSION_ACCOMPLISHED',
            onUrlChange: (url) => {
                userData.lastUrl = url;
                console.log(`[阶段1] URL 变化: ${url}`);

                // 检查是否遇到 email-verification 页面或其他可能导致问题的页面
                // if (url.includes('email-verification')) {
                //     console.log(`[阶段1] 检测到 email-verification 页面，继续等待...`);
                // }
            },
            onTargetReached: (url) => {
                userData.lastUrl = url;
                console.log(`[阶段1] 检测到 MISSION_ACCOMPLISHED 页面，注册流程完成！`);
                return url;
            },
            timeout: 900000 // 15分钟超时
        });
    } catch (error) {
        console.error(`[阶段1] CDP 连接错误: ${error.message}`);
        // 不立即抛出错误，而是尝试继续
        throw new Error(`阶段1失败: ${error.message}`);
    }

    browserbase.disconnect();

    return finalUrl;
}

/**
 * 第二阶段：Codex OAuth 授权
 */
async function phase2(browserbase, oauthService, userData) {
    console.log('\n=========================================');
    console.log('[阶段2] 开始 Codex OAuth 授权流程');
    console.log('=========================================');

    // 重新生成 PKCE 参数
    oauthService.regeneratePKCE();

    // 获取 OAuth URL
    const authUrl = oauthService.getAuthUrl();
    console.log(`[阶段2] OAuth URL: ${authUrl.substring(0, 100)}...`);

    // 创建新的会话
    const session = await browserbase.createSession();

    // 构建 Agent Goal
    const goal = `选择导航到${authUrl}，使用${userData.mail}作为邮箱，${userData.password}作为密码登录，发送验证码后在${userData.mailInboxUrl}上等待接收自己的邮箱验证码${config.clearMailbox.enable ? config.clearMailbox.prompt : ''}，选择登录到codex，地址跳转到localhost回调链接，出现无法访问的页面后记录当前完整url并结束。

如果遇到https://auth.openai.com/add-phone页面，请立即停止并返回错误。

完成任务之前不能结束, 每次等待的时间不得超过3秒。`;

    console.log('[阶段2] Agent Goal 已准备');

    // 发送 Agent 任务
    browserbase.sendAgentGoal(goal).catch(e => {
        console.error(`[阶段2] Agent 任务流异常: ${e.message}`);
    });

    // 连接 CDP 监控 URL 变化
    const wsUrl = session.wsUrl;
    if (!wsUrl) {
        throw new Error('无法从 sessionUrl 中提取 WSS 地址');
    }

    console.log('[阶段2] 开始监控页面 URL 变化，等待 localhost 回调...');

    // 监控直到到达 localhost 或 add-phone 页面
    const callbackUrl = await browserbase.connectToCDP(wsUrl, {
        targetKeyword: 'localhost',
        onUrlChange: (url) => {
            userData.lastUrl = url;
            console.log(`[阶段2] URL 变化: ${url}`);

            // 检查是否遇到 add-phone 页面
            if (url.includes('https://auth.openai.com/add-phone')) {
                throw new Error('遇到 https://auth.openai.com/add-phone 页面，需要添加手机号，直接丢弃此流程');
            }
        },
        onTargetReached: (url) => {
            userData.lastUrl = url;
            console.log(`[阶段2] 检测到 localhost 回调！`);
            return url;
        },
            timeout: 900000 // 15分钟超时
    });

    console.log(`[阶段2] 回调 URL: ${callbackUrl}`);
    userData.lastUrl = callbackUrl;

    // 提取授权参数
    const params = oauthService.extractCallbackParams(callbackUrl);
    if (!params || params.error) {
        throw new Error(`OAuth 授权失败: ${params?.error_description || params?.error || '未知错误'}`);
    }

    if (!params.code) {
        throw new Error('回调 URL 中未找到授权码');
    }

    console.log(`[阶段2] 成功获取授权码: ${params.code.substring(0, 10)}...`);

    // 用授权码换取 Token
    const tokenData = await oauthService.exchangeTokenAndSave(params.code, userData.mail);

    browserbase.disconnect();

    return tokenData;
}

/**
 * 单次注册流程
 */
async function runSingleRegistration(currentConfig) {
    console.log('\n=========================================');
    console.log('[主程序] 开始一次全新的注册与授权流程');
    console.log('=========================================');

    const accountStore = new AccountStore();
    const browserbase = new BrowserbaseService();
    const oauthService = new OAuthService(currentConfig);
    let userData = null;
    let currentStatus = '[准备] 进行';

    try {
        // 0. 生成用户数据
        userData = await generateUniqueUserData(currentConfig, accountStore);
        await accountStore.createAccount(userData.mail, userData.password, formatStatusText(currentStatus, userData.lastUrl));

        console.log(`[主程序] 用户数据已生成:`);
        console.log(`  - 邮箱: ${userData.mail}`);
        console.log(`  - 姓名: ${userData.fullName}`);
        console.log(`  - 年龄: ${userData.age}`);
        console.log(`  - 出生日期: ${userData.birthDate}`);

        // 1. 第一阶段：ChatGPT 注册
        currentStatus = '[一阶段] 进行';
        await accountStore.updateStatus(userData.mail, formatStatusText(currentStatus, userData.lastUrl));
        await phase1(browserbase, userData);
        currentStatus = '[一阶段] 完成';
        await accountStore.updateStatus(userData.mail, formatStatusText(currentStatus, userData.lastUrl));

        // 2. 第二阶段：Codex OAuth 授权
        currentStatus = '[二阶段] 进行';
        await accountStore.updateStatus(userData.mail, formatStatusText(currentStatus, userData.lastUrl));
        const tokenData = await phase2(browserbase, oauthService, userData);
        currentStatus = '[二阶段] 完成';
        await accountStore.updateStatus(userData.mail, formatStatusText(currentStatus, userData.lastUrl));
        await accountStore.updateRefreshToken(userData.mail, tokenData.refresh_token);

        console.log('[主程序] 本次注册流程圆满结束！');
        console.log(`[主程序] Token 已保存，邮箱: ${tokenData.email}`);

        return true;

    } catch (error) {
        if (userData?.mail) {
            const failedStatus = currentStatus.startsWith('[二阶段]') ? '[二阶段] 错误' : '[一阶段] 错误';
            await accountStore.updateStatus(userData.mail, formatStatusText(failedStatus, userData.lastUrl));
        }
        console.error('[主程序] 本次任务执行失败:', error.message);
        throw error;
    } finally {
        browserbase.disconnect();
    }
}

/**
 * 检查 token 数量
 */
async function checkTokenCount() {
    const outputDir = path.join(process.cwd(), 'tokens');
    if (!fs.existsSync(outputDir)) {
        return 0;
    }
    const files = fs.readdirSync(outputDir).filter(f => f.startsWith('token_') && f.endsWith('.json'));
    return files.length;
}

/**
 * 归档已有 tokens
 */
function archiveExistingTokens() {
    const outputDir = path.join(process.cwd(), 'tokens');
    if (!fs.existsSync(outputDir)) return;

    const files = fs.readdirSync(outputDir).filter(f => f.startsWith('token_') && f.endsWith('.json'));
    for (const file of files) {
        const oldPath = path.join(outputDir, file);
        const newPath = path.join(outputDir, `old_${file}`);
        fs.renameSync(oldPath, newPath);
        console.log(`[归档] ${file} → old_${file}`);
    }
}

/**
 * 执行单个注册任务
 */
async function executeSingleRegistration() {
    const currentConfig = config.currentConfig;
    if (!currentConfig) {
        throw new Error('没有可用的配置文件');
    }

    if (currentConfig.mode === 'ddg') {
        if (config.isDdgTokenUsed(currentConfig.ddgToken) || config.isDdgTokenReserved(currentConfig.ddgToken)) {
            throw new Error('当前 DDG token 不可用');
        }

        config.reserveDdgToken(currentConfig.ddgToken);
    }

    // 检查配置
    if (currentConfig.mode === 'ddg') {
        if (!currentConfig.ddgToken) {
            throw new Error('未配置 ddgToken，请检查配置文件');
        }
    } else if (!currentConfig.mail) {
        throw new Error('未配置 mail，请检查配置文件');
    }

    if (!currentConfig.mailInboxUrl) {
        throw new Error('未配置 mailInboxUrl，请检查配置文件');
    }

    try {
        await runSingleRegistration(currentConfig);

        if (currentConfig.mode === 'ddg') {
            config.markDdgTokenUsed(currentConfig.ddgToken);
        }

        return true;
    } catch (error) {
        console.error('[注册任务] 执行失败:', error.message);

        // 检查错误信息是否包含add-phone相关内容
        if (error.message.includes('add-phone')) {
            console.log('[注册任务] 遇到add-phone页面，丢弃当前注册流程...');

            if (currentConfig.mode === 'ddg') {
                config.markDdgTokenUsed(currentConfig.ddgToken);
            }

            throw error; // 抛出错误，让调用方处理
        }

        // 检查错误信息是否包含CDP连接相关错误
        if (error.message.includes('CDP') || error.message.includes('410') || error.message.includes('WebSocket')) {
            console.log('[注册任务] 遇到CDP连接错误，丢弃当前注册流程...');
            throw error; // 抛出错误，让调用方处理
        }

        throw error;
    } finally {
        if (currentConfig.mode === 'ddg' && !config.isDdgTokenUsed(currentConfig.ddgToken)) {
            config.releaseDdgToken(currentConfig.ddgToken);
        }
    }
}

/**
 * 并发控制函数
 */
async function runWithConcurrency(tasks, limit) {
    const results = [];
    const executing = [];

    for (let i = 0; i < tasks.length; i++) {
        const taskPromise = tasks[i]().then(result => ({ result, index: i }))
            .catch(error => ({ error, index: i }));

        results.push(taskPromise);

        if (results.length >= limit) {
            const completed = await Promise.race(results.map(p => p.then(r => r.index)));
            results.splice(completed, 1);
        }
    }

    return Promise.all(results);
}

/**
 * 启动批量注册
 */
async function startBatch() {
    console.log(`[启动] 开始执行 Codex 远程注册机，目标生成数量: ${TARGET_COUNT}，并发数: ${CONCURRENT_LIMIT}`);

    // 检查是否有可用配置
    if (!config.hasAvailableConfig()) {
        console.error('[错误] 没有找到任何配置文件');
        process.exit(1);
    }

    // 归档已有的 token 文件
    archiveExistingTokens();

    // 使用队列管理待执行的任务
    let completedCount = 0;
    const startTime = Date.now();

    while (completedCount < TARGET_COUNT) {
        // 计算当前批次需要执行的任务数
        const remainingTasks = Math.min(CONCURRENT_LIMIT, TARGET_COUNT - completedCount);
        const currentBatch = [];

        // 创建当前批次的任务
        for (let i = 0; i < remainingTasks; i++) {
            currentBatch.push(executeSingleRegistration);
        }

        console.log(`\n[进度] 批次开始 - 目标: ${completedCount}/${TARGET_COUNT}, 并发数: ${remainingTasks}`);

        try {
            // 执行当前批次
            const promises = currentBatch.map(task =>
                task().catch(err => {
                    console.error(`[任务] 执行出错: ${err.message}`);
                    return { error: err };
                })
            );

            const results = await Promise.allSettled(promises);

            // 统计成功和失败的任务
            let successful = 0;
            for (const result of results) {
                if (result.status === 'fulfilled') {
                    successful++;
                    completedCount++;
                } else {
                    console.error(`[任务] 执行失败: ${result.reason?.message}`);
                }

                // 检查是否已达到目标数量
                if (completedCount >= TARGET_COUNT) {
                    break;
                }
            }

            console.log(`[批次结果] 成功: ${successful}, 总计: ${results.length}, 当前总数: ${completedCount}/${TARGET_COUNT}`);

        } catch (error) {
            console.error('[批次执行] 出现错误:', error.message);
        }

        // 检查是否已完成目标
        if (completedCount >= TARGET_COUNT) {
            break;
        }

        // 添加小延迟以避免过于频繁的请求
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    const endTime = Date.now();
    console.log(`\n[完成] 所有任务完成！耗时: ${(endTime - startTime) / 1000}s`);
}

startBatch().catch(console.error);
